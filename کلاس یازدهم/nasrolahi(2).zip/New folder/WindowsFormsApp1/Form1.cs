﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n1 = int.Parse(textBox1.Text);
            int n2 = int.Parse(textBox2.Text);

            string result = "";


            int i = 1;
            while (i <= n1)
            {
                int j = i;
                while (j < n1)
                {
                    result += "";
                    j++;
                }

                int k = 1;
                while (k <= (2 * i - 1))
                {
                    result += " *";
                    k++;
                }

                result += "\n";
                i++;
            }



            i = n2 - 1;
            while (i >= 1)
            {
                int j = i;
                while (j < n2)
                {
                    result += "";
                    j++;
                }

                int k = 1;
                while (k <= (2 * i - 1))
                {
                    result += " *";
                    k++;
                }

                result += "\n";
                i--;
            }

            label1.Text = result;
        }
    }
}
