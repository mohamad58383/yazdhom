﻿namespace Nasro
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbl_chap = new Button();
            label1 = new Label();
            txt_row = new TextBox();
            SuspendLayout();
            // 
            // lbl_chap
            // 
            lbl_chap.Location = new Point(34, 22);
            lbl_chap.Name = "lbl_chap";
            lbl_chap.Size = new Size(155, 129);
            lbl_chap.TabIndex = 0;
            lbl_chap.Text = "chap";
            lbl_chap.UseVisualStyleBackColor = true;
            lbl_chap.Click += chap_Click;
            // 
            // label1
            // 
            label1.Location = new Point(261, 156);
            label1.Name = "label1";
            label1.Size = new Size(319, 295);
            label1.TabIndex = 1;
            label1.Text = "label1";
            // 
            // txt_row
            // 
            txt_row.Location = new Point(601, 61);
            txt_row.Name = "txt_row";
            txt_row.Size = new Size(167, 23);
            txt_row.TabIndex = 2;
            txt_row.Text = "row";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txt_row);
            Controls.Add(label1);
            Controls.Add(lbl_chap);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button lbl_chap;
        private Label label1;
        private TextBox txt_row;
    }
}
