﻿namespace Nasro
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void chap_Click(object sender, EventArgs e)
        {
            try
            {
                int rows = int.Parse(txt_row.Text);

                if (rows % 2 == 0)
                {
                    MessageBox.Show("عدد باید فرد باشد");
                    return;
                }

                // شروع ساخت هرم
                string result = "";

                for (int i = 1; i <= rows; i++)
                {
                    // فاصله‌ها برای وسط‌چین کردن
                    for (int j = i; j < rows; j++)
                    {
                        result += " ";
                    }

                    // ستاره‌ها
                    for (int k = 1; k <= (2 * i - 1); k++)
                    {
                        result += "*";
                    }

                    result += "\n";
                }

                lbl_chap.Font = new Font("Consolas", 12); // فونت ثابت برای تراز شدن دقیق
                lbl_chap.Text = result;
            }
            catch
            {
                MessageBox.Show("ورودی معتبر نیست");
            }
        }
    }
}
