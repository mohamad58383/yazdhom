﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        bool flag = false;
        int time85 = 30;
        private void Form1_MouseEnter(object sender, EventArgs e)
        {
            lblzaman.Text = time85.ToString();
            timer1.Enabled = false;
            if (flag == true)
            {
                MessageBox.Show("اچش نی همه یکبار میرینند");

                this.Close();
            }
        }

        private void buttaid_Click(object sender, EventArgs e)
        {

            flag = true;
            timer1.Enabled = true;
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            flag = false;
            timer1.Enabled = false;
            MessageBox.Show("نععععع باریکککککللللااا");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            time85--;
            lblzaman.Text = time85.ToString();
            if (time85 <= 0)
            {
                timer1.Enabled = false;
                if (flag == true)
                {
                    MessageBox.Show("زمانت به پایان رسید");


                }

            }
        }
    }
}

