﻿namespace Numeric_matrix
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Click = new Button();
            lbl_show = new Label();
            txt_col = new TextBox();
            txt_row = new TextBox();
            SuspendLayout();
            // 
            // Click
            // 
            Click.Location = new Point(579, 51);
            Click.Name = "Click";
            Click.Size = new Size(157, 139);
            Click.TabIndex = 0;
            Click.Text = "Click";
            Click.UseVisualStyleBackColor = true;
            Click.Click += Click_Click;
            // 
            // lbl_show
            // 
            lbl_show.BackColor = SystemColors.AppWorkspace;
            lbl_show.Location = new Point(12, 33);
            lbl_show.Name = "lbl_show";
            lbl_show.Size = new Size(306, 379);
            lbl_show.TabIndex = 1;
            lbl_show.Text = "lbl_show";
            // 
            // txt_col
            // 
            txt_col.Location = new Point(579, 346);
            txt_col.Name = "txt_col";
            txt_col.Size = new Size(157, 23);
            txt_col.TabIndex = 2;
            txt_col.Text = "col";
            // 
            // txt_row
            // 
            txt_row.Location = new Point(579, 299);
            txt_row.Name = "txt_row";
            txt_row.Size = new Size(157, 23);
            txt_row.TabIndex = 3;
            txt_row.Text = "row";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txt_row);
            Controls.Add(txt_col);
            Controls.Add(lbl_show);
            Controls.Add(Click);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Click;
        private Label lbl_show;
        private TextBox txt_col;
        private TextBox txt_row;
    }
}
