namespace Numeric_matrix
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Click_Click(object sender, EventArgs e)
        {
            lbl_show.Text = "";
            try
            {
                int row = int.Parse(txt_row.Text);
                int col = int.Parse(txt_col.Text);

                for (int a = 1; a <= row; a++)
                {
                    for (int b = 1; b <= col; b++)
                    {



                        lbl_show.Text = lbl_show.Text + b.ToString() + "    ";

                    }
                    lbl_show.Text = lbl_show.Text + "\n";
                }
            }
            catch
            {
            }
        }
    }
}
